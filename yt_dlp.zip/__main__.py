#!/usr/bin/env python

import os
import datetime
import shutil
import os.path
import time
import argparse
from datetime import date

def main():

    us = """
هذا الخطأ متوقع، يرجى إعادة تثبيت التطبيق
إنتقل للصفحة الرئيسية للتطبيق ثم إختر 
# التحديث وإعادة التثبيت # 
ثم قم بالضغط على 
# إعادة تثبيت التطبيق # 
إذا استمرت المشكلة يرجى إرسال رسالة عن طريق الضغط على أيقونة الرسالة في الصفحة الرئيسية للتطبيق 
أو مراسلتي على البريد الإلكتروني 
ibr.shukaili@gmail.com 

هذا الخطأ حدث عند التحديث إلى الإصدار 2.2.5 ولا يمكننا إرسال تحديث تلقائي لحل المشكلة لذلك يجب عليك إعادة تثبيت التطبيق لحل مشكلة التحديث.
 كانت الطريقة الوحيدة للتواصل معك هي مقاطعة عمليات التنزيل، وإشعارك بالحل وطريقة التحديث.
 
         """

    parser = argparse.ArgumentParser(usage = us, description='Add watermark to photos and videos')
    parser.add_argument("file", help="file accept image or video.")
    parser.add_argument('--img',
                    action="store_true",
                    help='add watermark to image.')
    parser.add_argument('--fix',
                    action="store_true",
                    help='fix image before add watermark.')
    parser.add_argument('--vid',
                    action="store_true",
                    help='add watermark to video without audio.')
    parser.add_argument('--audio',
                    action="store_true",
                    help='add watermark to video with audio.')
    parser.add_argument('--mp3',
                    action="store_true",
                    help='Convert video to mp3 file')
    parser.add_argument('--mp4',
                    action="store_true",
                    help='Convert video')
    parser.add_argument('--dump-json', '-r',
                    action='store_true',
                    help='print script version.')
    parser.add_argument('-v', '--version',
                    action='version',
                    version='%(prog)s 1.0',
                    help="Show program's version number and exit.")

    args = parser.parse_args()

    version = '0.1.3'
    # parse the video URL from command line
    url = args.file


    if not vars(args):
        error('x')
        exit()

    if args.version or args.v:
       print('version ' + version)
       exit()


    is_path = True

    if is_path:
        path = "storage/shared/download/"
    else:
        path = ""

    today = date.today()

    # dd/mm/YY
    d1 = today.strftime("%Y.%m.%d")
    audio = path + "audio.aac"
    inputs = path + url
    outputs = path + "output.mp4"
    font_path = path + "font.ttf"
    mp3_output = path + "audio.mp3"
    watermark_path = path + "watermark.png"

#    image_in = path + "input.jpg"
    image_in = path + url
    image_in_fixed = path + "fixed.jpg"
    if not os.path.exists(watermark_path):
        print('The watermark image was not found, script try to get it from server...')
        os.system('curl -O https://www.bhr-m.com/watermark.png')
        print('move watermark image')
        shutil.move("watermark.png", watermark_path)
    if not os.path.exists(watermark_path):
        print('can not get watermark from local storage or server!')
        exit()
    if args.mp4:
        print('add date to video')
        os.system('ffmpeg -i ' + inputs + ' -vf "drawtext=fontfile=' + font_path + ':text="' + d1 + '":fontcolor=white:fontsize=18:box=1:boxcolor=black@0.5:boxborderw=5:x=w-tw-10:y=10" -codec:a copy ' + path + 'output_with_date.mp4')
    elif args.mp3:
        if not os.path.exists(inputs):
            print('input file was not found!')
            exit()
        print('extrct audio as mp3')
        os.system('ffmpeg -i ' + inputs + ' -acodec libmp3lame ' + mp3_output)
        print('        finish convert file to mp3 format!')
    elif args.img:
        if args.fix:
            if not os.path.exists(image_in):
                print('error file not found! ' + os.path.basename(image_in) + ' in path: ' + path)
                exit()
            ext = os.path.splitext(image_in)[1]
            timestr = time.strftime("%Y%m%d-%H%M%S")
            file_name = path + timestr + str(ext)
            print('     fix image auto-orient...')
            os.system('mogrify -auto-orient ' + image_in)
            print('     resize image to 1512x792...')
            os.system('magick convert -quality 100 -resize 1512x792 ' + image_in + ' ' + image_in_fixed)
            print('     ' + os.path.basename(image_in) + ' fixed.')
            if os.path.exists(image_in):
                print('    deleting... ' + os.path.basename(image_in))
                os.remove(image_in)
            if os.path.exists(image_in_fixed):
                print('    renaming image... ' + os.path.basename(image_in_fixed))
                os.rename(image_in_fixed, image_in)
            print('     try adding watermark...')
            print('     Convert %s to %s' % (os.path.basename(image_in), os.path.basename(file_name)))
            os.system(
                'composite -dissolve 40%% -gravity SouthWest %s "%s" "%s"' % (watermark_path, image_in, file_name))
            if os.path.exists(image_in):
                print('    deleting... ' + os.path.basename(image_in))
                os.remove(image_in)
            print("    watermark added. script exit...")
        else:
            if not os.path.exists(image_in):
                print('error file not found! ' + os.path.basename(image_in) + ' in path: ' + path)
                exit()
            ext = os.path.splitext(image_in)[1]
            timestr = time.strftime("%Y%m%d-%H%M%S")
            file_name = path + timestr + str(ext)
            print('     fix image...')
            os.system('mogrify -auto-orient ' + image_in)
            print('     try adding watermark...')
            print('     Convert %s to %s' % (os.path.basename(image_in), os.path.basename(file_name)))
            os.system(
                'composite -dissolve 40%% -gravity SouthWest %s "%s" "%s"' % (watermark_path, image_in, file_name))
            if os.path.exists(image_in):
                print('    deleting... ' + os.path.basename(image_in))
                os.remove(image_in)
            print("    watermark added. script exit...")

    elif args.vid:
        if args.audio:
            if not os.path.exists(inputs):
                print('error file not found! ' + inputs)
                exit()

            ext = os.path.splitext(inputs)[1]
            # name = os.path.splitext(inputs)[0]
            timestr = time.strftime("%Y%m%d-%H%M%S")
            file_name = path + timestr + str(ext)

            print('    extract audio...')
            os.system('ffmpeg -i ' + inputs + ' -vn -acodec copy ' + audio)
            print('    add watermark...')
            os.system(
                'ffmpeg -y -i ' + inputs + ' -i ' + watermark_path + ' -filter_complex "[1]lut=a=val*0.3[a];[0][a]overlay=5:main_h-overlay_h" -c:v libx264 -an ' + outputs)
            print("    add audio...")
            os.system('ffmpeg -i ' + outputs + ' -i ' + audio + ' -c:v copy -c:a aac ' + file_name)
            if os.path.exists(inputs):
                print('    deleting... ' + os.path.basename(inputs))
                os.remove(inputs)
            if os.path.exists(audio):
                print('    deleting... ' + os.path.basename(audio))
                os.remove(audio)
            if os.path.exists(outputs):
                print('    deleting... ' + os.path.basename(outputs))
                os.remove(outputs)
            print('    finish.')
        else:
            if not os.path.exists(inputs):
                print('error file not found! ' + os.path.basename(inputs))
                exit()

            ext = os.path.splitext(inputs)[1]
            # name = os.path.splitext(inputs)[0]
            timestr = time.strftime("%Y%m%d-%H%M%S")
            file_name = path + timestr + str(ext)

            os.system(
                'ffmpeg -y -i ' + inputs + ' -i ' + watermark_path + ' -filter_complex "[1]lut=a=val*0.3[a];[0][a]overlay=5:main_h-overlay_h" -c:v libx264 -an ' + file_name)
            if os.path.exists(inputs):
                print('    deleting... ' + os.path.basename(inputs))
                os.remove(inputs)
            print('    finish.')
    else:
        print("Please select one of the options to continue.")


if __name__ == '__main__':
    main()
